#!/bin/bash

# Consigna 5.5: Opción de ayuda
if [[ "$1" == "-help" ]]; then
  echo "Uso: $0 [directorio_origen] [directorio_destino]"
  echo "Ejemplo: $0 /var/log /backup_dir"
  exit 0
fi

# El script debe aceptar argumentos
ORIGEN=$1
DESTINO=$2

# Consigna 5.6: Validar que los directorios existan
if [[ ! -d "$ORIGEN" ]]; then
  echo "Error: El directorio de origen '$ORIGEN' no existe."
  exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
  echo "Error: El directorio de destino '$DESTINO' no existe."
  exit 1
fi

# Consigna 5.2: Nombre con formato de fecha YYYYMMDD
FECHA=$(date +%Y%m%d)
# Extraemos solo el nombre del directorio, ej: "log" de "/var/log"
NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

echo "Iniciando backup de '$ORIGEN' en '$ARCHIVO'..."

# Creamos el archivo tar.gz
# -c: crear
# -z: comprimir con gzip
# -f: especificar el nombre del archivo
tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE"

echo "Backup finalizado con éxito."
exit 0
